
import os
from pyrogram import filters
from client import bot
from bot.BOT.Charge.sitebase_chk.single import main as check_card
from bot.FUNC.usersdb_func import deduct_credits, get_user_credits
from pyrogram.types import Message
import asyncio

@bot.on_message(filters.command(["btch1", "btch5"]))
async def batch_check_handler(bot, message: Message):
    user_id = message.from_user.id
    charge = 1 if message.command[0] == "btch1" else 5

    await message.reply_text("Send me a .txt file with CCs, one per line.")
    
    # Wait for next message with a document
    doc_msg = await bot.listen(message.chat.id, filters=filters.document, timeout=60)
    file_path = await doc_msg.download()

    
from bot.FUNC.usersdb_func import get_user_plan

plan_limits = {
    "Free": 30,
    "Plan 1": 60,
    "Plan 2": 100,
    "Plan 3": 300
}

plan = await get_user_plan(user_id)

    plan_display = "Free User" if plan == "Free" else f"Premium User ({plan})"

max_cards = plan_limits.get(plan, 30)

with open(file_path, "r") as f:

        lines = f.read().splitlines()

    total = len(lines)

    if user_id != 6431329116 and total > max_cards:
        await message.reply_text(f"Your plan ({plan}) allows a maximum of {max_cards} cards per batch. You uploaded {total}.")
        return

    live, dead, unknown = [], [], []

    user_credits = await get_user_credits(user_id)
    if user_credits < total * charge:
        await message.reply_text("Not enough credits.")
        return

    await message.reply_text(f"Processing {total} cards...")

    for card in lines:
        result = await check_card(message, cc=card, charge=0, return_only=True)
        if "Live" in result:
            live.append(card)
        elif "Dead" in result:
            dead.append(card)
        else:
            unknown.append(card)
        await asyncio.sleep(1)

    # Deduct credits
    await deduct_credits(user_id, total * charge)

    # Save result files
    def save_list(name, data):
        fpath = f"/mnt/data/{name}.txt"
        with open(fpath, "w") as f:
            f.write("\n".join(data))
        return fpath

    files = []
    if live: files.append(save_list("live", live))
    if dead: files.append(save_list("dead", dead))
    if unknown: files.append(save_list("unknown", unknown))

    summary = f"""
Batch Check Completed:
Total: {total}
Live: {len(live)}
Dead: {len(dead)}
Unknown: {len(unknown)}
Plan: {plan_display}
Credits used: {total * charge}
    """
Batch Check Completed:
Total: {total}
Live: {len(live)}
Dead: {len(dead)}
Unknown: {len(unknown)}
Credits used: {total * charge}
    """

    await message.reply_text(summary.strip())
    for f in files:
        await message.reply_document(f)


async def send_result(message, cc, status, response, gateway):
    emoji = "✅" if status.lower() == "live" else "❌" if status.lower() == "dead" else "⚠️"
    username = f"@{message.from_user.username}" if message.from_user.username else f"tg://user?id={message.from_user.id}"
    result_text = f"""
<b>Result:</b> {emoji} <b>{status.upper()}</b>
<b>Card:</b> <code>{cc}</code>
<b>Response:</b> {response}
<b>Gate:</b> {gateway}
<b>Checked by:</b> {username}
<b>Bot by:</b> @omuteche
"""
    await message.reply_text(result_text.strip())
